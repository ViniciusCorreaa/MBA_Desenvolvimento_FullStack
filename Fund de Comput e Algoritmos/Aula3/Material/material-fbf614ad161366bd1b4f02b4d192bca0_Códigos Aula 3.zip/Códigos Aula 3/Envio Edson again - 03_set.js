// Video 2 - 27:30
var mySet = new Set()

mySet.add(0)
console.log(mySet)
console.log("-=-=-==-=")

mySet.add(1)
console.log(mySet)
console.log("-=-=-==-=")

mySet.add(1)
console.log(mySet)
console.log("-=-=-==-=")

mySet.add(2)
console.log(mySet)
console.log("-=-=-==-=")

mySet.add(3)
console.log(mySet)
console.log("-=-=-==-=")

mySet.add(2)
console.log(mySet)
console.log("-=-=-==-=")
