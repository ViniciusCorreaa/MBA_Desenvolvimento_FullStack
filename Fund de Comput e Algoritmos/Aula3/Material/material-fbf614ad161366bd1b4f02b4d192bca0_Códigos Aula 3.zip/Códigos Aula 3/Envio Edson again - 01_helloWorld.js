// video 1 - 06:55
console.log("Hello world!!!")
console.log("Fundamentos de computação e algoritmos")
